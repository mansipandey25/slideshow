import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatCard } from "@/components/stat-card";
import { Activity, Users, TrendingUp, Award } from "lucide-react";
import type { Member, WorkoutSession, Exercise } from "@shared/schema";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

export default function Analytics() {
  const { data: members = [] } = useQuery<Member[]>({
    queryKey: ["/api/members"],
  });

  const { data: sessions = [] } = useQuery<WorkoutSession[]>({
    queryKey: ["/api/sessions"],
  });

  const { data: exercises = [] } = useQuery<Exercise[]>({
    queryKey: ["/api/exercises"],
  });

  const completedSessions = sessions.filter((s) => s.status === "completed");
  const totalMembers = members.length;
  const activeMembers = members.filter((m) => m.isActive).length;
  const avgAccuracy = completedSessions.length > 0
    ? Math.round(
        completedSessions.reduce((acc, s) => acc + s.averagePostureAccuracy, 0) /
          completedSessions.length
      )
    : 0;
  const totalSessions = completedSessions.length;

  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    return date.toISOString().split("T")[0];
  });

  const dailyStats = last7Days.map((date) => {
    const daySessions = completedSessions.filter(
      (s) => new Date(s.startTime).toISOString().split("T")[0] === date
    );
    return {
      date: new Date(date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
      sessions: daySessions.length,
      calories: Math.round(daySessions.reduce((acc, s) => acc + s.caloriesBurned, 0)),
      accuracy: daySessions.length > 0
        ? Math.round(
            daySessions.reduce((acc, s) => acc + s.averagePostureAccuracy, 0) /
              daySessions.length
          )
        : 0,
    };
  });

  const exerciseStats = exercises
    .map((exercise) => {
      const exerciseSessions = completedSessions.filter((s) => s.exerciseId === exercise.id);
      return {
        name: exercise.name.length > 15 ? exercise.name.slice(0, 15) + "..." : exercise.name,
        sessions: exerciseSessions.length,
        avgAccuracy: exerciseSessions.length > 0
          ? Math.round(
              exerciseSessions.reduce((acc, s) => acc + s.averagePostureAccuracy, 0) /
                exerciseSessions.length
            )
          : 0,
      };
    })
    .filter((stat) => stat.sessions > 0)
    .sort((a, b) => b.sessions - a.sessions)
    .slice(0, 5);

  const memberEngagement = members
    .map((member) => {
      const memberSessions = completedSessions.filter((s) => s.memberId === member.id);
      return {
        name: member.name.split(" ")[0],
        sessions: memberSessions.length,
        calories: Math.round(memberSessions.reduce((acc, s) => acc + s.caloriesBurned, 0)),
      };
    })
    .filter((stat) => stat.sessions > 0)
    .sort((a, b) => b.sessions - a.sessions)
    .slice(0, 5);

  return (
    <div className="flex-1 space-y-6 p-6">
      <div>
        <h1 className="font-display text-4xl font-bold" data-testid="heading-analytics">
          Analytics Dashboard
        </h1>
        <p className="text-muted-foreground mt-1">
          Comprehensive insights into gym performance and member engagement
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Members"
          value={totalMembers}
          icon={Users}
          testId="stat-total-members"
        />
        <StatCard
          title="Active Members"
          value={activeMembers}
          icon={Activity}
          trend={{ value: 10, isPositive: true }}
          testId="stat-active-members-analytics"
        />
        <StatCard
          title="Total Sessions"
          value={totalSessions}
          icon={TrendingUp}
          trend={{ value: 18, isPositive: true }}
          testId="stat-total-sessions"
        />
        <StatCard
          title="Avg Accuracy"
          value={`${avgAccuracy}%`}
          icon={Award}
          trend={{ value: 3, isPositive: true }}
          testId="stat-avg-accuracy-analytics"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-semibold">Performance Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={dailyStats}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis
                  dataKey="date"
                  className="text-xs"
                  tick={{ fill: "hsl(var(--muted-foreground))" }}
                />
                <YAxis className="text-xs" tick={{ fill: "hsl(var(--muted-foreground))" }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "0.5rem",
                  }}
                  labelStyle={{ color: "hsl(var(--foreground))" }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="sessions"
                  stroke="hsl(var(--chart-1))"
                  strokeWidth={2}
                  name="Sessions"
                />
                <Line
                  type="monotone"
                  dataKey="accuracy"
                  stroke="hsl(var(--chart-2))"
                  strokeWidth={2}
                  name="Accuracy %"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-semibold">Daily Calories Burned</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={dailyStats}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis
                  dataKey="date"
                  className="text-xs"
                  tick={{ fill: "hsl(var(--muted-foreground))" }}
                />
                <YAxis className="text-xs" tick={{ fill: "hsl(var(--muted-foreground))" }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "0.5rem",
                  }}
                  labelStyle={{ color: "hsl(var(--foreground))" }}
                />
                <Bar dataKey="calories" fill="hsl(var(--chart-3))" radius={[4, 4, 0, 0]} name="Calories" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-semibold">Popular Exercises</CardTitle>
          </CardHeader>
          <CardContent>
            {exerciseStats.length === 0 ? (
              <div className="flex items-center justify-center py-12 text-muted-foreground">
                No exercise data available
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={exerciseStats} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis type="number" className="text-xs" tick={{ fill: "hsl(var(--muted-foreground))" }} />
                  <YAxis
                    type="category"
                    dataKey="name"
                    className="text-xs"
                    tick={{ fill: "hsl(var(--muted-foreground))" }}
                    width={100}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "0.5rem",
                    }}
                    labelStyle={{ color: "hsl(var(--foreground))" }}
                  />
                  <Bar dataKey="sessions" fill="hsl(var(--chart-1))" radius={[0, 4, 4, 0]} name="Sessions" />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-semibold">Member Engagement</CardTitle>
          </CardHeader>
          <CardContent>
            {memberEngagement.length === 0 ? (
              <div className="flex items-center justify-center py-12 text-muted-foreground">
                No member data available
              </div>
            ) : (
              <div className="space-y-4">
                {memberEngagement.map((member, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 rounded-lg border border-border hover-elevate"
                    data-testid={`member-engagement-${index}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10 text-primary font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <div className="font-medium">{member.name}</div>
                        <div className="text-sm text-muted-foreground">
                          {member.sessions} sessions
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold text-chart-3">
                        {member.calories.toLocaleString()} cal
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
