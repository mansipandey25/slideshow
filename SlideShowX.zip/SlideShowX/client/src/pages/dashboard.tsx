import { useQuery } from "@tanstack/react-query";
import { Activity, Flame, Target, Users } from "lucide-react";
import { StatCard } from "@/components/stat-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import type { Member, WorkoutSession, Exercise } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

export default function Dashboard() {
  const { data: members = [], isLoading: loadingMembers } = useQuery<Member[]>({
    queryKey: ["/api/members"],
  });

  const { data: sessions = [], isLoading: loadingSessions } = useQuery<WorkoutSession[]>({
    queryKey: ["/api/sessions"],
  });

  const { data: exercises = [] } = useQuery<Exercise[]>({
    queryKey: ["/api/exercises"],
  });

  const activeMembers = members.filter((m) => m.isActive).length;
  const todaySessions = sessions.filter(
    (s) => new Date(s.startTime).toDateString() === new Date().toDateString()
  ).length;
  
  const avgAccuracy = sessions.length > 0
    ? Math.round(
        sessions.reduce((acc, s) => acc + s.averagePostureAccuracy, 0) / sessions.length
      )
    : 0;
  
  const totalCalories = Math.round(
    sessions.reduce((acc, s) => acc + s.caloriesBurned, 0)
  );

  const activeSessions = sessions.filter((s) => s.status === "in_progress");
  const recentSessions = sessions
    .filter((s) => s.status === "completed")
    .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime())
    .slice(0, 5);

  const getExerciseName = (exerciseId: string) => {
    return exercises.find((e) => e.id === exerciseId)?.name || "Unknown Exercise";
  };

  const getMemberName = (memberId: string) => {
    return members.find((m) => m.id === memberId)?.name || "Unknown Member";
  };

  return (
    <div className="flex-1 space-y-6 p-6">
      <div>
        <h1 className="font-display text-4xl font-bold" data-testid="heading-dashboard">
          Dashboard
        </h1>
        <p className="text-muted-foreground mt-1">
          Real-time overview of your gym's performance
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Active Members"
          value={activeMembers}
          icon={Users}
          trend={{ value: 12, isPositive: true }}
          testId="stat-active-members"
        />
        <StatCard
          title="Sessions Today"
          value={todaySessions}
          icon={Activity}
          trend={{ value: 8, isPositive: true }}
          testId="stat-sessions-today"
        />
        <StatCard
          title="Avg Accuracy"
          value={`${avgAccuracy}%`}
          icon={Target}
          trend={{ value: 5, isPositive: true }}
          testId="stat-avg-accuracy"
        />
        <StatCard
          title="Total Calories"
          value={totalCalories.toLocaleString()}
          icon={Flame}
          trend={{ value: 15, isPositive: true }}
          testId="stat-total-calories"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-4">
            <CardTitle className="text-xl font-semibold">Live Sessions</CardTitle>
            <Badge variant="secondary" className="gap-1">
              <span className="h-2 w-2 rounded-full bg-chart-2 animate-pulse" />
              {activeSessions.length} Active
            </Badge>
          </CardHeader>
          <CardContent>
            {loadingSessions ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-16 bg-muted rounded-md animate-pulse" />
                ))}
              </div>
            ) : activeSessions.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Activity className="h-12 w-12 text-muted-foreground mb-3" />
                <p className="text-sm text-muted-foreground">No active workout sessions</p>
                <Link href="/workout">
                  <Button className="mt-4" data-testid="button-start-workout">
                    Start Workout
                  </Button>
                </Link>
              </div>
            ) : (
              <div className="space-y-3">
                {activeSessions.map((session) => (
                  <div
                    key={session.id}
                    className="flex items-center justify-between p-4 rounded-lg border border-border bg-card hover-elevate"
                    data-testid={`session-${session.id}`}
                  >
                    <div className="flex-1">
                      <div className="font-medium">{getMemberName(session.memberId)}</div>
                      <div className="text-sm text-muted-foreground">
                        {getExerciseName(session.exerciseId)}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium text-chart-2">
                        {session.averagePostureAccuracy.toFixed(0)}% accuracy
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {session.reps} reps
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-semibold">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            {loadingSessions || loadingMembers ? (
              <div className="space-y-4">
                {[1, 2, 3, 4, 5].map((i) => (
                  <div key={i} className="h-16 bg-muted rounded-md animate-pulse" />
                ))}
              </div>
            ) : recentSessions.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Activity className="h-12 w-12 text-muted-foreground mb-3" />
                <p className="text-sm text-muted-foreground">No recent sessions</p>
              </div>
            ) : (
              <div className="space-y-3">
                {recentSessions.map((session) => (
                  <div
                    key={session.id}
                    className="flex items-center gap-4 p-3 rounded-lg border border-border hover-elevate"
                    data-testid={`recent-session-${session.id}`}
                  >
                    <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                      <Activity className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">
                        {getMemberName(session.memberId)}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {getExerciseName(session.exerciseId)}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">
                        {session.caloriesBurned.toFixed(0)} cal
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(session.startTime), { addSuffix: true })}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
