import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Activity, Camera, Flame, Play, Square, Target, Timer } from "lucide-react";
import type { Member, Exercise, WorkoutSession } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import * as poseDetection from "@tensorflow-models/pose-detection";
import * as tf from "@tensorflow/tfjs";
import "@tensorflow/tfjs-backend-webgl";

export default function Workout() {
  const { toast } = useToast();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const detectorRef = useRef<poseDetection.PoseDetector | null>(null);
  const animationFrameRef = useRef<number>(0);
  const postureScoresRef = useRef<number[]>([]);
  const repCountRef = useRef<number>(0);
  const lastPoseYRef = useRef<number>(0);
  const movingDownRef = useRef<boolean>(false);
  
  const [isRecording, setIsRecording] = useState(false);
  const [selectedMember, setSelectedMember] = useState<string>("");
  const [selectedExercise, setSelectedExercise] = useState<string>("");
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [duration, setDuration] = useState(0);
  const [reps, setReps] = useState(0);
  const [currentAccuracy, setCurrentAccuracy] = useState(0);
  const [caloriesBurned, setCaloriesBurned] = useState(0);
  const [isLoadingModel, setIsLoadingModel] = useState(false);

  const { data: members = [] } = useQuery<Member[]>({
    queryKey: ["/api/members"],
  });

  const { data: exercises = [] } = useQuery<Exercise[]>({
    queryKey: ["/api/exercises"],
  });

  const startSessionMutation = useMutation({
    mutationFn: async (data: { memberId: string; exerciseId: string }) => {
      const res = await apiRequest("POST", "/api/sessions", data);
      return await res.json() as WorkoutSession;
    },
    onSuccess: (data) => {
      setSessionId(data.id);
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      toast({
        title: "Session started",
        description: "AI pose detection is now active",
      });
    },
  });

  const endSessionMutation = useMutation({
    mutationFn: async (data: {
      id: string;
      duration: number;
      reps: number;
      caloriesBurned: number;
      avgAccuracy: number;
      postureScores: number[];
    }) => {
      return await apiRequest("PATCH", `/api/sessions/${data.id}`, {
        endTime: new Date(),
        duration: data.duration,
        reps: data.reps,
        caloriesBurned: data.caloriesBurned,
        averagePostureAccuracy: data.avgAccuracy,
        postureScores: data.postureScores,
        status: "completed",
      });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      toast({
        title: "Session completed",
        description: `Great work! ${variables.reps} reps completed with ${variables.avgAccuracy.toFixed(0)}% accuracy`,
      });
    },
  });

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecording) {
      interval = setInterval(() => {
        setDuration((prev) => prev + 1);
        const exercise = exercises.find((e) => e.id === selectedExercise);
        if (exercise) {
          setCaloriesBurned((prev) => prev + (exercise.caloriesPerMinute / 60));
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording, selectedExercise, exercises]);

  useEffect(() => {
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, []);

  const calculatePostureAccuracy = (pose: poseDetection.Pose): number => {
    if (!pose.keypoints || pose.keypoints.length === 0) return 0;

    const visibleKeypoints = pose.keypoints.filter((kp) => kp.score && kp.score > 0.3);
    if (visibleKeypoints.length < 5) return 0;

    const avgConfidence = visibleKeypoints.reduce((sum, kp) => sum + (kp.score || 0), 0) / visibleKeypoints.length;
    
    const leftShoulder = pose.keypoints.find((kp) => kp.name === "left_shoulder");
    const rightShoulder = pose.keypoints.find((kp) => kp.name === "right_shoulder");
    const leftHip = pose.keypoints.find((kp) => kp.name === "left_hip");
    const rightHip = pose.keypoints.find((kp) => kp.name === "right_hip");

    let alignmentScore = 1.0;
    if (leftShoulder && rightShoulder && leftShoulder.score && rightShoulder.score && leftShoulder.score > 0.3 && rightShoulder.score > 0.3) {
      const shoulderAlignment = Math.abs(leftShoulder.y - rightShoulder.y);
      alignmentScore *= Math.max(0, 1 - shoulderAlignment / 100);
    }

    if (leftHip && rightHip && leftHip.score && rightHip.score && leftHip.score > 0.3 && rightHip.score > 0.3) {
      const hipAlignment = Math.abs(leftHip.y - rightHip.y);
      alignmentScore *= Math.max(0, 1 - hipAlignment / 100);
    }

    const accuracy = (avgConfidence * 0.6 + alignmentScore * 0.4) * 100;
    return Math.min(100, Math.max(0, accuracy));
  };

  const detectRep = (pose: poseDetection.Pose) => {
    const nose = pose.keypoints.find((kp) => kp.name === "nose");
    if (!nose || !nose.score || nose.score < 0.3) return;

    const currentY = nose.y;
    const threshold = 50;

    if (!movingDownRef.current && currentY > lastPoseYRef.current + threshold) {
      movingDownRef.current = true;
    } else if (movingDownRef.current && currentY < lastPoseYRef.current - threshold) {
      movingDownRef.current = false;
      repCountRef.current += 1;
      setReps(repCountRef.current);
    }

    lastPoseYRef.current = currentY;
  };

  const drawSkeleton = (poses: poseDetection.Pose[], ctx: CanvasRenderingContext2D) => {
    poses.forEach((pose) => {
      if (!pose.keypoints) return;

      pose.keypoints.forEach((keypoint) => {
        if (keypoint.score && keypoint.score > 0.3) {
          ctx.beginPath();
          ctx.arc(keypoint.x, keypoint.y, 5, 0, 2 * Math.PI);
          ctx.fillStyle = "#3b82f6";
          ctx.fill();
        }
      });

      const connections = [
        ["left_shoulder", "right_shoulder"],
        ["left_shoulder", "left_elbow"],
        ["left_elbow", "left_wrist"],
        ["right_shoulder", "right_elbow"],
        ["right_elbow", "right_wrist"],
        ["left_shoulder", "left_hip"],
        ["right_shoulder", "right_hip"],
        ["left_hip", "right_hip"],
        ["left_hip", "left_knee"],
        ["left_knee", "left_ankle"],
        ["right_hip", "right_knee"],
        ["right_knee", "right_ankle"],
      ];

      connections.forEach(([start, end]) => {
        const startPoint = pose.keypoints.find((kp) => kp.name === start);
        const endPoint = pose.keypoints.find((kp) => kp.name === end);

        if (
          startPoint &&
          endPoint &&
          startPoint.score &&
          endPoint.score &&
          startPoint.score > 0.3 &&
          endPoint.score > 0.3
        ) {
          ctx.beginPath();
          ctx.moveTo(startPoint.x, startPoint.y);
          ctx.lineTo(endPoint.x, endPoint.y);
          ctx.strokeStyle = "#60a5fa";
          ctx.lineWidth = 2;
          ctx.stroke();
        }
      });
    });
  };

  const detectPose = async () => {
    if (!detectorRef.current || !videoRef.current || !canvasRef.current || !isRecording) {
      return;
    }

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    if (!ctx || video.readyState < 2) {
      animationFrameRef.current = requestAnimationFrame(detectPose);
      return;
    }

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    try {
      const poses = await detectorRef.current.estimatePoses(video);

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (poses.length > 0) {
        const pose = poses[0];
        const accuracy = calculatePostureAccuracy(pose);
        setCurrentAccuracy(accuracy);
        postureScoresRef.current.push(accuracy);

        detectRep(pose);
        drawSkeleton(poses, ctx);
      }
    } catch (error) {
      console.error("Pose detection error:", error);
    }

    animationFrameRef.current = requestAnimationFrame(detectPose);
  };

  const initializePoseDetection = async () => {
    try {
      setIsLoadingModel(true);
      await tf.setBackend("webgl");
      await tf.ready();

      const model = poseDetection.SupportedModels.MoveNet;
      const detectorConfig: poseDetection.MoveNetModelConfig = {
        modelType: poseDetection.movenet.modelType.SINGLEPOSE_LIGHTNING,
      };
      
      detectorRef.current = await poseDetection.createDetector(model, detectorConfig);
      setIsLoadingModel(false);
    } catch (error) {
      console.error("Failed to load pose detection model:", error);
      setIsLoadingModel(false);
      toast({
        title: "Model loading failed",
        description: "Could not initialize AI pose detection",
        variant: "destructive",
      });
    }
  };

  const startWorkout = async () => {
    if (!selectedMember || !selectedExercise) {
      toast({
        title: "Selection required",
        description: "Please select a member and exercise",
        variant: "destructive",
      });
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 640, height: 480 },
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      if (!detectorRef.current) {
        await initializePoseDetection();
      }

      await startSessionMutation.mutateAsync({
        memberId: selectedMember,
        exerciseId: selectedExercise,
      });

      setIsRecording(true);
      setDuration(0);
      setReps(0);
      repCountRef.current = 0;
      setCaloriesBurned(0);
      setCurrentAccuracy(0);
      postureScoresRef.current = [];
      lastPoseYRef.current = 0;
      movingDownRef.current = false;

      detectPose();
    } catch (error) {
      console.error("Camera error:", error);
      toast({
        title: "Camera access denied",
        description: "Please allow camera access to start workout tracking",
        variant: "destructive",
      });
    }
  };

  const stopWorkout = async () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
    }

    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }

    const avgAccuracy = postureScoresRef.current.length > 0
      ? postureScoresRef.current.reduce((a, b) => a + b, 0) / postureScoresRef.current.length
      : 0;

    if (sessionId) {
      await endSessionMutation.mutateAsync({
        id: sessionId,
        duration,
        reps,
        caloriesBurned,
        avgAccuracy,
        postureScores: [...postureScoresRef.current],
      });
    }

    setIsRecording(false);
    setSessionId(null);
    setDuration(0);
    setReps(0);
    repCountRef.current = 0;
    setCurrentAccuracy(0);
    setCaloriesBurned(0);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="flex-1 p-6">
      <div className="mb-6">
        <h1 className="font-display text-4xl font-bold" data-testid="heading-workout">
          Live Workout
        </h1>
        <p className="text-muted-foreground mt-1">
          Real-time AI-powered pose detection and form analysis
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-4">
          <Card className="overflow-hidden">
            <CardContent className="p-0">
              <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                  data-testid="video-camera"
                />
                <canvas
                  ref={canvasRef}
                  className="absolute inset-0 w-full h-full"
                  data-testid="canvas-pose"
                />

                {!isRecording && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                    <div className="text-center">
                      <Camera className="h-16 w-16 text-white/50 mx-auto mb-4" />
                      <p className="text-white text-lg font-medium">
                        {isLoadingModel
                          ? "Loading AI model..."
                          : "Select member and exercise to start"}
                      </p>
                    </div>
                  </div>
                )}

                {isRecording && (
                  <>
                    <div className="absolute top-4 right-4">
                      <Badge variant="destructive" className="gap-2" data-testid="badge-recording">
                        <span className="h-2 w-2 rounded-full bg-white animate-pulse" />
                        RECORDING
                      </Badge>
                    </div>
                    <div className="absolute top-4 left-4 bg-black/70 backdrop-blur-sm rounded-lg px-3 py-2">
                      <div
                        className="text-white font-bold text-2xl tabular-nums"
                        data-testid="text-accuracy"
                      >
                        {currentAccuracy.toFixed(0)}%
                      </div>
                      <div className="text-white/70 text-xs">Accuracy</div>
                    </div>
                  </>
                )}
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-4 sm:grid-cols-2">
            <Select
              value={selectedMember}
              onValueChange={setSelectedMember}
              disabled={isRecording}
            >
              <SelectTrigger data-testid="select-member">
                <SelectValue placeholder="Select Member" />
              </SelectTrigger>
              <SelectContent>
                {members
                  .filter((m) => m.isActive)
                  .map((member) => (
                    <SelectItem key={member.id} value={member.id}>
                      {member.name}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>

            <Select
              value={selectedExercise}
              onValueChange={setSelectedExercise}
              disabled={isRecording}
            >
              <SelectTrigger data-testid="select-exercise">
                <SelectValue placeholder="Select Exercise" />
              </SelectTrigger>
              <SelectContent>
                {exercises.map((exercise) => (
                  <SelectItem key={exercise.id} value={exercise.id}>
                    {exercise.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-4">
          <Card>
            <CardContent className="p-6">
              {!isRecording ? (
                <Button
                  size="lg"
                  className="w-full gap-2"
                  onClick={startWorkout}
                  disabled={!selectedMember || !selectedExercise || isLoadingModel}
                  data-testid="button-start-workout"
                >
                  <Play className="h-5 w-5" />
                  {isLoadingModel ? "Loading AI..." : "Start Workout"}
                </Button>
              ) : (
                <Button
                  size="lg"
                  variant="destructive"
                  className="w-full gap-2"
                  onClick={stopWorkout}
                  data-testid="button-stop-workout"
                >
                  <Square className="h-5 w-5" />
                  Stop Workout
                </Button>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 space-y-6">
              <div>
                <div className="flex items-center gap-2 text-muted-foreground mb-2">
                  <Timer className="h-4 w-4" />
                  <span className="text-sm font-medium">Duration</span>
                </div>
                <div className="text-3xl font-bold tabular-nums" data-testid="text-duration">
                  {formatDuration(duration)}
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 text-muted-foreground mb-2">
                  <Activity className="h-4 w-4" />
                  <span className="text-sm font-medium">Reps</span>
                </div>
                <div className="text-3xl font-bold tabular-nums" data-testid="text-reps">
                  {reps}
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 text-muted-foreground mb-2">
                  <Flame className="h-4 w-4" />
                  <span className="text-sm font-medium">Calories</span>
                </div>
                <div className="text-3xl font-bold tabular-nums" data-testid="text-calories">
                  {caloriesBurned.toFixed(0)}
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 text-muted-foreground mb-2">
                  <Target className="h-4 w-4" />
                  <span className="text-sm font-medium">Form Accuracy</span>
                </div>
                <div
                  className="text-3xl font-bold tabular-nums text-chart-2"
                  data-testid="text-form-accuracy"
                >
                  {currentAccuracy.toFixed(0)}%
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
